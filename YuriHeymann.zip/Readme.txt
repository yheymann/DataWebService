MarketData webservice
MarketData database

1. Query timeseries market data from DB
2. Update / Insert quotes in the market data DB