﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.OleDb;

namespace WebService
{
    /// <summary>
    /// Summary description for DataService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class DataService : System.Web.Services.WebService
    {

        [WebMethod]
        public string PushQuote(double quote)
        {
            OleDbConnection cnn;
            string connectionString = @"Provider = Microsoft.ACE.OLEDB.15.0; Data Source = C:\Temp\MyData.accdb";
            cnn = new OleDbConnection(connectionString);
            try
            {
                cnn.Open();
                DateTime now = DateTime.Now;
                OleDbCommand sqlCommand = new OleDbCommand("Insert into Tesla (quote,date) values ("+quote+","+now+")", cnn);
                sqlCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

            }
            finally
            {
                cnn.Close();
            }
            return "done";
        }

        [WebMethod]
        public DataSet GetTimeSeries()
        {
            DataSet ds = new DataSet("TimeSeries");
            OleDbConnection cnn;
            string connectionString = @"Provider = Microsoft.ACE.OLEDB.15.0; Data Source = C:\Temp\MyData.accdb";
            //string connectionString = @"Driver={Microsoft Access Driver (*.mdb, *.accdb)};Dbq=C:\Temp\MyData.accdb;Uid=Admin;Pwd=;";
            cnn = new OleDbConnection(connectionString);
            try
            {
                cnn.Open();

                //OleDbCommand sqlCommand = new OleDbCommand("Select * from Tesla", cnn);
                OleDbDataAdapter adapter = new OleDbDataAdapter("Select * from Tesla", cnn);
                
                adapter.Fill(ds, "Tesla");

            }catch(Exception ex)
            {

            }
            finally
            {
                cnn.Close();
            }

            return ds;
        }
    }
}
